<head>
    <title><?php echo $__env->yieldContent('pageTitle'); ?> || Mehta Plywoods</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name='description' content='A Description for your company website'>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel='canonical' href='<?php echo e(url()->current()); ?>'>
    <?php echo $__env->make('includes.partials.favicon', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.partials.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('plugins-style'); ?>

    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    
    <!-- endinject -->
    <?php echo $__env->yieldContent('page-style'); ?>
</head>
