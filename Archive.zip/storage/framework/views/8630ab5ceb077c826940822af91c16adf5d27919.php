<?php $__env->startSection('pageTitle', 'Home'); ?>
<?php $__env->startSection('plugins-style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section>
	<div class="container">
		<div class="row align-items-center justify-content-between">
			<div class="col-lg-5 order-2 order-lg-1">
				<h4 class="mb-0">We Revolutionise</h4>
				<h1 class="mb-4">The Wood Industry</h1>
				
				
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore ratione, veritatis, in at nihil earum officia quas beatae incidunt. Aspernatur obcaecati adipisci et asperiores quae reprehenderit aperiam eligendi consequuntur quos!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum enim consequatur libero vitae velit dolorem placeat ipsum reprehenderit nihil optio dolor cumque ad soluta, corrupti facere eaque impedit, magni iste!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore ratione, veritatis, in at nihil earum officia quas beatae incidunt. Aspernatur obcaecati adipisci et asperiores quae reprehenderit aperiam eligendi consequuntur quos!</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum enim consequatur libero vitae velit dolorem placeat ipsum reprehenderit nihil optio dolor cumque ad soluta, corrupti facere eaque impedit, magni iste!</p>
			</div>
			<div class="col-lg-6 order-1 order-lg-2 mb-sp mb-lg-0">
				<div class="row justify-content-center">
					<div class="col-8 col-md-10 col-lg-10">
						<img class="img-fluid d-block mx-auto" src="<?php echo e(asset('img/extra/wood.png')); ?>" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<!-- Modal -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins-scripts'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>