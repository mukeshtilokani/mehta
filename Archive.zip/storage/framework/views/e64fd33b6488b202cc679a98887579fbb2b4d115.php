<?php $__env->startSection('pageTitle', 'Home'); ?>
<?php $__env->startSection('plugins-style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>

<?php $__env->startSection('content'); ?>


<section id="hero">
	<div class="container">
		<div class="row align-items-center justify-content-between">
			<div class="col-lg-5 order-2 order-lg-1">
				<h4 class="mb-0">We Revolutionise</h4>
				<h1 class="mb-4">The Wood Industry</h1>
				
				
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore ratione, veritatis, in at nihil earum officia quas beatae incidunt. Aspernatur obcaecati adipisci et asperiores quae reprehenderit aperiam eligendi consequuntur quos!</p>
			</div>
			<div class="col-lg-6 order-1 order-lg-2 mb-sp mb-lg-0">
				<div class="row justify-content-center">
					<div class="col-8 col-md-10 col-lg-10">
						<img class="img-fluid d-block mx-auto" src="<?php echo e(asset('img/extra/wood.png')); ?>" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



<section class="bg-light">
	<div class="container">
		<div class="row align-items-center justify-content-between">
			<div class="col-lg-6">
				<div class="row">
					<div class="col-6 mb-gt">
						<img class="img-fluid" src="<?php echo e(asset('https://picsum.photos/540/540?image=101')); ?>" alt="">
					</div>
					<div class="col-6 mb-gt">
						<img class="img-fluid" src="<?php echo e(asset('https://picsum.photos/540/540?image=201')); ?>" alt="">
					</div>
					<div class="col-6 mb-gt">
						<img class="img-fluid" src="<?php echo e(asset('https://picsum.photos/540/540?image=301')); ?>" alt="">
					</div>
					<div class="col-6 mb-gt">
						<img class="img-fluid" src="<?php echo e(asset('https://picsum.photos/540/540?image=401')); ?>" alt="">
					</div>
				</div>
			</div>
			<div class="col-lg-5">
				<div class="row">
					<div class="col-12">
						<h1 class="hero-text">Our products</h1>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6">
						<a href="" class="btn btn-primary w-100">See more</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>



<?php echo $__env->make('includes.testimonial', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<!-- Modal -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins-scripts'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>