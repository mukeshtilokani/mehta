<!DOCTYPE html>
<html class="html" lang="<?php echo e(app()->getLocale()); ?>">
    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <body>
        <div class="wrapper">
            <?php echo $__env->yieldContent('banner'); ?>
            
            <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <div id="content">
                
                <?php echo $__env->make('includes.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                
                <!-- body start -->
                <main class="cd-main-content">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
                <!-- body end -->
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="overlay"></div>
        <?php echo $__env->yieldContent('modal'); ?>
        <?php echo $__env->yieldContent('page-scripts'); ?>
    </body>
</html>
