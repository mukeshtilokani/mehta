<meta property='og:type' content='website'/>
<meta property='og:url' content='<?php echo e(url()->current()); ?>'/>
<meta property='og:title' content='<?php echo $__env->yieldContent('pageTitle'); ?> || Mehta Plywood'/>
<meta property='og:description' content='Content'/>
<meta property="og:site_name" content="Mehta Plywood"/>
<meta property='og:image' content='<?php echo e(url('/img/banner/banner.jpg')); ?>'/>
<meta property="og:image:type" content="image/png" />
<meta property="og:image:alt" content="Mehta Plywood splash image" />
<meta property="og:image:width" content="1920" />
<meta property="og:image:height" content="1080" />
<meta name='twitter:card' content='summary_large_image'>
<meta name='twitter:domain' value='<?php echo e(Request::root()); ?>'/>
<meta name='twitter:title' value='<?php echo $__env->yieldContent('pageTitle'); ?> || Mehta Plywood'/>
<meta name='twitter:description' value='Content'/>
<meta name='twitter:image' content='<?php echo e(url('/img/banner/banner.jpg')); ?>'/>
<meta name='twitter:url' value='<?php echo e(url()->current()); ?>'/>

<meta name='twitter:creator' content='@parthshah000'/>

