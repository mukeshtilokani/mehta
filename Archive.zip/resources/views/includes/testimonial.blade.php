{{-- Testimonial --}}
<section>
	<div class="container">
		<div class="row align-items-center justify-content-center testimonials-section">
			<div class="col-lg-8">
				<div id="testimonials" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner text-center">
						<div class="carousel-item active">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam optio placeat ducimus, libero maxime quas nobis alias ratione quam fugit sapiente veniam obcaecati doloremque id laboriosam natus labore in perferendis?</p>
							<h5>John Diggle</h5>
						</div>
						<div class="carousel-item">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam optio placeat ducimus, libero maxime quas nobis alias ratione quam fugit sapiente veniam obcaecati doloremque id laboriosam natus labore in perferendis?</p>
							<h5>John Diggle</h5>
						</div>
						<div class="carousel-item">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam optio placeat ducimus, libero maxime quas nobis alias ratione quam fugit sapiente veniam obcaecati doloremque id laboriosam natus labore in perferendis?</p>
							<h5>John Diggle</h5>
						</div>
					</div>
					<ol class="carousel-indicators mt-4">
					    <li data-target="#testimonials" data-slide-to="0" class="active"></li>
					    <li data-target="#testimonials" data-slide-to="1"></li>
					    <li data-target="#testimonials" data-slide-to="2"></li>
					</ol>
				</div>
			</div>
		</div>
	</div>
</section>
{{-- End of testimonial --}}